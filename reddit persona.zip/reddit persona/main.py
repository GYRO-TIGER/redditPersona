import praw
import re
import os
import requests
import matplotlib.pyplot as plt
from collections import Counter

REDDIT_CLIENT_ID = 'FRCgIEmX10zPfheaWgEevw'
REDDIT_CLIENT_SECRET = 'h4uWCQ7FfcXGsHOCdjv7P3H4XiQuLA'
REDDIT_USER_AGENT = 'user persona builder'
HUGGINGFACE_API_TOKEN = "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"

def extract_username(url):
    match = re.search(r'reddit\.com/user/([\w-]+)/?', url)
    return match.group(1) if match else None

def fetch_data(reddit, username, limit=500):
    user = reddit.redditor(username)
    posts, comments = [], []
    for post in user.submissions.new(limit=limit):
        posts.append({'title': post.title, 'selftext': post.selftext, 'subreddit': str(post.subreddit)})
    for comment in user.comments.new(limit=limit):
        comments.append({'body': comment.body, 'subreddit': str(comment.subreddit)})
    return posts, comments

def extract_traits(posts, comments):
    traits, sources = {}, {}
    all_subs = [p['subreddit'] for p in posts] + [c['subreddit'] for c in comments]
    top_subs = Counter(all_subs).most_common(5)
    traits['Top Subreddits'] = ', '.join([s[0] for s in top_subs])
    sources['Top Subreddits'] = f"From: {', '.join([s[0] for s in top_subs])}"

    total_posts, total_comments = len(posts), len(comments)
    traits['Activity'] = "Highly Active" if (total_posts + total_comments) > 150 else "Moderately Active"
    sources['Activity'] = f"Posts: {total_posts}, Comments: {total_comments}"

    all_text = ' '.join(p['selftext'] for p in posts if p['selftext']) + ' ' + ' '.join(c['body'] for c in comments)
    avg_len = sum(len(c['body']) for c in comments) / len(comments) if comments else 0
    traits['Writing Style'] = "Formal" if avg_len > 120 else "Informal"
    sources['Writing Style'] = f"Average length: {int(avg_len)}"

    hobby_words = ['music', 'gaming', 'travel', 'books', 'tech', 'sports', 'coding']
    hobbies_found = [kw for kw in hobby_words if kw in all_text.lower()]
    traits['Mentioned Hobbies'] = ', '.join(set(hobbies_found)) if hobbies_found else "Not found"
    sources['Mentioned Hobbies'] = ', '.join(hobbies_found)

    return traits, sources, all_text, top_subs, total_posts, total_comments

def generate_persona(username, traits, text_sample):
    prompt = f"""
Below are traits and content from a Reddit user. Create a persona paragraph describing their interests, tone, personality, and inferred traits.

Username: u/{username}
Traits: {traits}
Sample Text: {text_sample[:1500]}
"""

    headers = {
        "Authorization": f"Bearer {HUGGINGFACE_API_TOKEN}"
    }

    data = {
        "inputs": prompt,
        "parameters": {
            "max_new_tokens": 300,
            "do_sample": True,
            "temperature": 0.7
        }
    }

    response = requests.post(
        "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1",
        headers=headers,
        json=data
    )

    if response.status_code == 200:
        return response.json()[0]['generated_text'].strip()
    else:
        print(f"❌ Hugging Face API Error: {response.status_code}")
        return "[!] Persona generation failed."

def save_persona(username, traits, sources, persona_text):
    dir_path = os.path.join(os.path.expanduser('~'), 'Downloads', 'Reddit Persona')
    os.makedirs(dir_path, exist_ok=True)
    file_path = os.path.join(dir_path, f"{username}_persona.txt")
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(f"USER PERSONA for u/{username}\n")
        f.write("="*60 + "\n\n")
        f.write("AI-GENERATED PERSONA:\n")
        f.write(persona_text + "\n\n")
        f.write("EXTRACTED TRAITS:\n")
        for k in traits:
            f.write(f"{k}: {traits[k]}\n")
            f.write(f"  ↳ {sources[k]}\n")
    print(f"[✓] Persona saved to {file_path}")

def plot_charts(username, top_subs, total_posts, total_comments):
    dir_path = os.path.join(os.path.expanduser('~'), 'Downloads', 'Reddit Persona')
    os.makedirs(dir_path, exist_ok=True)

    subs, counts = zip(*top_subs)
    plt.figure(figsize=(8,5))
    plt.barh(subs[::-1], counts[::-1], color='skyblue')
    plt.title(f"Top Subreddits - u/{username}")
    plt.xlabel("Post/Comment Count")
    plt.tight_layout()
    plt.savefig(os.path.join(dir_path, f"{username}_subreddits_chart.png"))
    plt.close()

    plt.figure()
    plt.pie([total_posts, total_comments], labels=['Posts', 'Comments'], autopct='%1.1f%%', startangle=140, colors=['#66b3ff','#99ff99'])
    plt.title(f"Activity Breakdown - u/{username}")
    plt.savefig(os.path.join(dir_path, f"{username}_activity_chart.png"))
    plt.close()

    print("[✓] Charts saved.")

def main():
    profile = input("Enter Reddit profile URL: ").strip()
    username = extract_username(profile)
    if not username:
        print("❌ Invalid URL.")
        return

    reddit = praw.Reddit(client_id=REDDIT_CLIENT_ID,
                         client_secret=REDDIT_CLIENT_SECRET,
                         user_agent=REDDIT_USER_AGENT)

    print(f"[+] Fetching data for u/{username} ...")
    posts, comments = fetch_data(reddit, username)

    if not posts and not comments:
        print("❗ No data found.")
        return

    traits, sources, full_text, top_subs, total_posts, total_comments = extract_traits(posts, comments)

    print(f"[+] Generating persona with Hugging Face API ...")
    persona_text = generate_persona(username, traits, full_text)

    print(f"[+] Saving data ...")
    save_persona(username, traits, sources, persona_text)
    plot_charts(username, top_subs, total_posts, total_comments)

if __name__ == "__main__":
    main()
